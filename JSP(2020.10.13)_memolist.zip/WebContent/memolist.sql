SELECT * FROM memolist ORDER BY idx DESC;

# 자동증가가 다시 1부터 시작 되게 한다.
DELETE FROM memolist;
ALTER TABLE memolist AUTO_INCREMENT = 1;